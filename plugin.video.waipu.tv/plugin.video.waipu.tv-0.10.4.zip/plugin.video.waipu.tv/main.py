# -*- coding: utf-8 -*-
# Module: default
# Author: flubshi
# Created on: 2018-06-02
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from lib import waipu

if __name__ == '__main__':
    waipu.run()
